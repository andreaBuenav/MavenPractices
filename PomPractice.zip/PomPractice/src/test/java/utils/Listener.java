package utils;


import mainDriver.MainDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;
import pages.ShoppingCartPage;

public class Listener implements ITestListener {
//    @Override
//    public void onTestFailure(ITestResult result) {
//        System.out.println("Test failed: " + result.getName());
//    }



}
